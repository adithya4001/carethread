# CareThread demonstration walkthrough

Record 21–23 minutes of explanation and actual prototype operation. This outline is not a video.

1. Minutes 0–2: Explain the care-continuity problem and disclose that all providers/data are fictional. Distinguish the browser demonstration from the included connected backend.
2. Minutes 2–5: Open a care episode. Enter symptom history and onset date, add a structured check-in and a synthetic original report. Explain that symptoms are not a confirmed diagnosis.
3. Minutes 5–7: Choose a category-matched clinician. Confirm sharing consent. Show that the case is awaiting review and no treatment plan is approved.
4. Minutes 7–10: Switch to Clinician. Open original reports and current history. Write a specific follow-up plan, confirm the latest revision was reviewed and approve it. Return to Patient to view the plan.
5. Minutes 10–13: Request an appointment or transport simulation. Switch to Clinic desk, accept the request, then provide a separate demo confirmation reference. Show that request submission alone is not confirmation.
6. Minutes 13–15: Add worsening/new symptoms or a new report. Show that the plan becomes historical and requires reassessment. Reapprove the current revision. Demonstrate consent withdrawal and explain connected-backend access revocation.
7. Minutes 15–17: Open the Digital twin lab. Explain its separate Type 2 diabetes use case, EHR/sensor fusion and next-hour prediction. Freeze a prediction and reveal the future outcome.
8. Minutes 17–19: Disclose exact synthetic metrics, low spike recall and unknown future meals. Show the generator, train/validation/test subject split and tests.
9. Minutes 19–21: Return to the patient workflow, request recovery review and close it as the clinician. Show that patient ID and history persist. Explain genuine service integrations and operational controls that a real pilot would require.

After recording, verify duration, readability and audio. Upload through an organiser-accepted route, add the accessible video URL and real team details to README, and test judge access while signed out.
