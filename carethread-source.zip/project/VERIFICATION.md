# Verification - 19 October 2026

## Automated

16 tests passed in the complete source project and after independently expanding the public runnable release package. Coverage includes consent, role/assignment checks, revision-specific approval, worsening updates, original reports, provider acknowledgement/confirmation, recovery history, account isolation, file access, request Origin validation, staff invitations, logout, numerical forecasting parity and exclusion of future inputs.

The backend HTTP integration test uses an in-memory SQLite database and 127.0.0.1 only. It does not provision a hosted patient service or a real clinician.

## Public deployment

GitHub repository: https://github.com/adithya4001/carethread

GitHub Pages demonstration: https://adithya4001.github.io/carethread/

The standard Pages branch build completed successfully and the public UI was opened in a browser. The public release serves flat static assets from main / (root); the full source archive also contains a docs/ build for other deployments.

## Browser checks performed

- Patient shared the fictional sample case with the general-medicine fixture after explicit consent.
- The assigned demo clinician wrote a specific fictional test plan and approved the recorded revision.
- Patient appointment request appeared as requested, then accepted by the fictional clinic, then confirmed only after entering a separate demo reference.
- A new symptom invalidated the previous plan and returned the case to review.
- A synthetic text attachment was saved, survived reload, and downloaded with exact original content.
- The updated synthetic history and original report were reviewed before a new demo plan was recorded.
- Patient requested closure; the fictional clinician added a closing test summary; the case archived with the same patient ID and history.
- The original diabetes lab opened on the public deployment. Prediction replay revealed actual values and an error table after freezing the forecast.
- At a mobile breakpoint, document scroll width equalled document client width (375 CSS pixels), with no horizontal overflow. The viewport override was reset afterward.
- No JavaScript errors were returned by the browser error log during the completed care workflow.
- Test-only browser records were cleared using the app's explicit reset flow, restoring the synthetic sample.

Microphone/camera recording was not exercised with personal input. No real medical advice, treatment decision, hospital request, booking or ambulance dispatch occurred. The account backend is included and tested but not hosted by GitHub Pages.
