# CareThread architecture

## Public demonstration

GitHub Pages serves the built docs folder. Episode data stays in localStorage and attachment blobs stay in IndexedDB. A deliberately labelled demo role selector exercises the same pure transition functions used by the backend. Role switching is a simulation, not access control.

## Connected backend

Browser UI communicates with same-origin /api routes. Node.js 24 provides HTTP, crypto and SQLite without external packages. SQLite stores users, hashed session tokens, episode JSON, original file blobs and audit records. The backend checks each account's role, patient ownership, assigned provider and current sharing consent on every protected operation.

Patient intake creates a persistent patient ID and separate episode ID. Explicit consent assigns a fictional directory provider. Approval requires a clinician identity matching that provider and the latest episode revision. A worsening/new symptom or report increments the revision and invalidates the old plan. Coordination requests progress through requested, accepted, confirmed and completed, with decline/cancel branches. A provider reference is mandatory for confirmation. Recovery requires a patient request followed by clinician closure. Archive keeps the record and patient identity.

Clinic responses operate on logistics fields. The connected clinic state omits original reports, messages, full symptoms and check-ins; attachment endpoints reject clinic accounts. Consent withdrawal removes access on the next request. Patient ownership continues to grant access.

## Forecast lab

Offline Python/NumPy fits multi-output ridge regression to an original synthetic generator. Browser JavaScript applies exported feature standardization and weights. The prediction uses past information only. Validation residuals provide empirical pointwise bands. Test subjects are disjoint from training/validation; replay reveals future readings after the forecast is frozen.

## External integrations

There are none. Provider directories and schedules are fixtures. No prescription, diagnostic AI, medical-report extraction, hospital messaging, real booking or ambulance API is connected. Production services must not mark a provider request confirmed until the actual provider acknowledges it. The current demonstration records fictional acknowledgements manually.

## Deployment boundary

The live Pages URL is a local-data demonstration. It cannot host the Node/SQLite service. Backend source and a hosting blueprint are included, but connected backend hosting and real provider onboarding require an operator's service account and deployment configuration. No such deployment is claimed by this source.
