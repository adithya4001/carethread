import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const target=path.join(root,'docs');
await fs.mkdir(target,{recursive:true});
await fs.cp(path.join(root,'dist'),target,{recursive:true});
await fs.writeFile(path.join(target,'.nojekyll'),'');
console.log('GitHub Pages output: docs/');
