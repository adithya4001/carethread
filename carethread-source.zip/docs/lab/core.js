export function features(profile, rows, i) {
  if(i<12 || i>=rows.length) throw Error('At least 13 readings are required.');
  const g=k=>rows[i-k].glucose, recent=Array.from({length:13},(_,k)=>g(k));
  const mean=recent.reduce((a,b)=>a+b,0)/13;
  const std=Math.sqrt(recent.reduce((a,b)=>a+(b-mean)**2,0)/13);
  const hour=((rows[i].minute%1440)+1440)%1440/60;
  return [...[0,1,2,3,6,9,12].map(g),g(0)-g(1),g(0)-g(3),g(0)-g(6),mean,std,
    rows[i].heart_rate,rows.slice(i-5,i+1).reduce((a,b)=>a+b.steps,0),profile.sleep_hours,
    profile.age,profile.bmi,profile.hba1c,profile.diabetes_years,
    Math.sin(hour*Math.PI/12),Math.cos(hour*Math.PI/12),profile.hba1c*(g(0)-g(3))];
}
export function forecast(model,profile,rows,i) {
 const raw=features(profile,rows,i), z=[1,...raw.map((x,j)=>(x-model.mean[j])/model.scale[j])];
 const values=model.horizons.map((_,h)=>Math.max(model.clip[0],Math.min(model.clip[1],rows[i].glucose+z.reduce((s,v,j)=>s+v*model.weights[j][h],0))));
 return {values,low:values.map((v,j)=>Math.max(40,v+model.residual_p10[j])),high:values.map((v,j)=>Math.min(400,v+model.residual_p90[j])),raw,z};
}
export function formatTime(minute) {
 const m=((minute%1440)+1440)%1440;
 return `${String(Math.floor(m/60)).padStart(2,'0')}:${String(m%60).padStart(2,'0')}`;
}
export function parseCSV(text) {
 const lines=text.trim().split(/\r?\n/);if(lines.length<14)throw Error('Upload at least 13 readings (one hour of history).');
 const header=lines.shift().split(',').map(x=>x.trim().replace(/^\uFEFF/,''));
 const fields=['minute','glucose','heart_rate','steps'];
 if(header.length!==4||!fields.every(x=>header.includes(x)))throw Error('CSV columns must be minute,glucose,heart_rate,steps.');
 if(lines.length>5000)throw Error('Keep the CSV below 5,000 readings.');
 const rows=lines.map((line,j)=>{
  const cells=line.split(',').map(s=>s.trim());
  if(cells.length!==4||cells.some(x=>x===''))throw Error(`Row ${j+2}: four numeric values are required.`);
  const row=Object.fromEntries(header.map((x,k)=>[x,Number(cells[k])]));
  if(!Object.values(row).every(Number.isFinite))throw Error(`Row ${j+2}: values must be finite numbers.`);
  if(!Number.isInteger(row.minute)||row.minute<0||row.glucose<40||row.glucose>400||row.heart_rate<30||row.heart_rate>220||row.steps<0||row.steps>2000)throw Error(`Row ${j+2}: reading outside supported input limits.`);
  return row;
 });
 rows.forEach((r,i)=>{if(i&&r.minute-rows[i-1].minute!==5)throw Error(`Row ${i+2}: readings must be ordered at exactly 5-minute intervals.`);});
 return rows;
}
export function mae(a,b){return a.reduce((s,x,i)=>s+Math.abs(x-b[i]),0)/a.length;}
