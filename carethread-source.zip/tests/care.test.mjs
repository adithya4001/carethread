import {test} from 'node:test';
import assert from 'node:assert/strict';
import {emptyState,createEpisode,applyAction,recommendedProviders} from '../dist/care.js';
const patient={id:'p1',role:'patient'},doctor={id:'d1',role:'doctor',providerId:'general'},clinic={id:'c1',role:'clinic',clinicId:'willow'};
const episode=()=>createEpisode({title:'Fever',symptoms:'Feeling tired since yesterday',onset:'2026-10-18'},'p1');
const share=e=>applyAction(e,{type:'share',data:{doctorId:'general',consent:true}},patient);
const approve=e=>applyAction(e,{type:'approve',data:{revision:e.revision,reviewed:true,instructions:'Demo follow-up: record your status at the agreed follow-up time.',followup:'Demo schedule'}},doctor);
test('Consent is required and only the assigned clinician can approve',()=>{
 const e=episode();assert.throws(()=>applyAction(e,{type:'share',data:{doctorId:'general',consent:false}},patient));
 assert.throws(()=>approve(e));const s=share(e);
 assert.throws(()=>applyAction(s,{type:'approve',data:{revision:s.revision,reviewed:true,instructions:'A sufficiently detailed follow-up plan.'}},{...doctor,providerId:'endo'}));
 assert.equal(approve(s).status,'approved');assert.equal(e.status,'draft');
});
test('Old revision or unchecked review cannot approve a plan',()=>{
 const e=share(episode());for(const data of [{revision:0,reviewed:true},{revision:e.revision,reviewed:false}])assert.throws(()=>applyAction(e,{type:'approve',data:{...data,instructions:'A sufficiently detailed follow-up plan.'}},doctor));
});
test('New or worsening symptoms invalidate approval and block new transport requests',()=>{
 let e=approve(share(episode()));e=applyAction(e,{type:'checkin',data:{feeling:'worse',temperature:38.5,newSymptoms:true}},patient);
 assert.equal(e.status,'needs_review');assert.ok(e.revision>e.reviewedRevision);
 assert.throws(()=>applyAction(e,{type:'request_task',data:{kind:'transport',details:'Demo transport request'}},patient));
});
test('New reports invalidate approval, while ordinary improving check-ins retain it',()=>{
 let e=approve(share(episode()));e=applyAction(e,{type:'checkin',data:{feeling:'better',temperature:37}},patient);assert.equal(e.status,'approved');
 e=applyAction(e,{type:'report',data:{id:'r1',name:'synthetic.txt',size:20}},patient);assert.equal(e.status,'needs_review');
});
test('Coordination requires acknowledgement and explicit confirmation, with clinic isolation',()=>{
 let e=share(episode());e=applyAction(e,{type:'request_task',data:{kind:'appointment',details:'Demo consultation request'}},patient);const id=e.tasks[0].id;
 assert.throws(()=>applyAction(e,{type:'task_status',data:{id,status:'confirmed',confirmation:'DEMO-123'}},clinic));
 assert.throws(()=>applyAction(e,{type:'task_status',data:{id,status:'accepted'}},{...clinic,clinicId:'northstar'}));
 e=applyAction(e,{type:'task_status',data:{id,status:'accepted'}},clinic);
 assert.throws(()=>applyAction(e,{type:'task_status',data:{id,status:'confirmed'}},clinic));
 e=applyAction(e,{type:'task_status',data:{id,status:'confirmed',confirmation:'DEMO-123'}},clinic);assert.equal(e.tasks[0].status,'confirmed');
});
test('Withdrawing consent cancels pending requests and prevents clinician actions',()=>{
 let e=share(episode());e=applyAction(e,{type:'request_task',data:{kind:'appointment',details:'Demo appointment'}},patient);e=applyAction(e,{type:'revoke'},patient);
 assert.equal(e.consent,false);assert.equal(e.tasks[0].status,'cancelled');assert.throws(()=>approve(e));
});
test('Patient ID persists; recovery needs clinician closure; archived cases preserve history',()=>{
 const state=emptyState('Test','p1'),id=state.profile.patientId;let e=approve(share(episode()));
 assert.throws(()=>applyAction(e,{type:'resolve',data:{summary:'Resolved after a clinician review.'}},doctor));
 e=applyAction(e,{type:'request_close'},patient);e=applyAction(e,{type:'resolve',data:{summary:'Demo recovery reviewed. Episode archived with history retained.'}},doctor);
 assert.equal(e.status,'resolved');assert.ok(e.events.length>3);assert.equal(state.profile.patientId,id);
 assert.throws(()=>applyAction(e,{type:'message',data:{text:'new message'}},patient));e=applyAction(e,{type:'reopen'},patient);assert.equal(e.status,'needs_review');
});
test('Category matching does not invent a diagnosis',()=>{assert.equal(recommendedProviders('diabetes')[0].id,'endo');assert.equal(recommendedProviders('general')[0].id,'general');assert.equal(episode().status,'draft');});
