import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {forecast,features,parseCSV} from '../dist/lab/core.js';
const model=JSON.parse(fs.readFileSync(new URL('../dist/lab/model.json',import.meta.url)));
const people=JSON.parse(fs.readFileSync(new URL('../dist/lab/patients.json',import.meta.url)));
const golden=JSON.parse(fs.readFileSync(new URL('./python-parity.json',import.meta.url)));
test('JavaScript inference matches Python training implementation at every horizon',()=>{
 for(const item of golden){const p=people[item.patient];const out=forecast(model,p.profile,p.readings,item.index);out.values.forEach((v,j)=>assert.ok(Math.abs(v-item.values[j])<1e-8));}
});
test('Forecast has no access to future readings',()=>{
 const p=people[0],i=p.profile.initial_index,a=forecast(model,p.profile,p.readings,i);
 const mutated=structuredClone(p.readings);for(let n=i+1;n<mutated.length;n++)mutated[n].glucose=399;
 assert.deepEqual(a.values,forecast(model,p.profile,mutated,i).values);
});
test('Static patient history and dynamic sensor history both affect inference',()=>{
 const p=people[0],i=p.profile.initial_index,a=forecast(model,p.profile,p.readings,i);
 const b=forecast(model,{...p.profile,hba1c:9.5,bmi:35},p.readings,i);
 assert.ok(a.values.some((v,j)=>Math.abs(v-b.values[j])>.1));
 const r=structuredClone(p.readings);r[i].glucose+=10;
 assert.notDeepEqual(a.values,forecast(model,p.profile,r,i).values);
});
test('Every demo is held out, has a valid origin and finite clipped inference',()=>{
 for(const p of people){assert.ok(Number(p.profile.id.split('-')[1])>=100);assert.equal(p.readings.length,864);assert.ok(p.profile.initial_index>=12);for(const i of [12,p.profile.initial_index,863]){const f=forecast(model,p.profile,p.readings,i);assert.equal(f.values.length,12);assert.ok(f.values.every(Number.isFinite));assert.ok(f.values.every(v=>v>=40&&v<=400));}}
});
test('Valid CSV imports preserve numeric data and reordered headers',()=>{
 const t='steps,heart_rate,glucose,minute\n'+Array.from({length:25},(_,i)=>`0,70,120,${i*5}`).join('\n');
 assert.equal(parseCSV(t).length,25);assert.equal(parseCSV(t)[24].minute,120);
});
test('CSV validation rejects missing data, NaN, duplicate time, irregular intervals and unsupported ranges',()=>{
 const head='minute,glucose,heart_rate,steps\n',lines=Array.from({length:13},(_,i)=>`${i*5},120,70,0`);
 for(const mutation of ['5,,70,0','5,Infinity,70,0','0,120,70,0','6,120,70,0','5,401,70,0']){const copy=[...lines];copy[1]=mutation;assert.throws(()=>parseCSV(head+copy.join('\n')));}
 assert.throws(()=>parseCSV(head+lines.slice(0,12).join('\n')));
});
test('Feature extraction requires a complete hour of history',()=>assert.throws(()=>features(people[0].profile,people[0].readings,11)));

